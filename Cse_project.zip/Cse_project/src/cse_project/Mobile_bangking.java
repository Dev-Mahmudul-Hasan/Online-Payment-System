
package cse_project;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Mobile_bangking implements ActionListener{
     JTextField t1, t2, t3;
    JLabel a1, a2, a3, a4, a5, a6;
    JButton b1, b2, b3, b4;
    Icon icon, icon1, icon2, icon3, icon4;
    JFrame f = new JFrame("S K Y  C A S H");

    public Mobile_bangking()
    
    {
        
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\User\\Downloads\\project hasanf.png");
        f.setIconImage(icon);
         JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        BufferedImage myPicture = null;
        try {
            myPicture = ImageIO.read(new File("C:\\Users\\User\\Downloads\\hasan.jpg"));
        } catch (IOException ex) {
            Logger.getLogger(JExercise.class.getName()).log(Level.SEVERE, null, ex);
        }
        JLabel picLabel = new JLabel(new ImageIcon(myPicture));
        panel.add(picLabel);
        
        
        
         a6 = new JLabel("MOBILE BANKING");
        a6.setBounds(580, 225, 300, 40);
        a6.setForeground(Color.WHITE);
        a6.setFont(new Font("Monospaced", Font.BOLD, 20));
        f.add(a6);

       

        t1 = new JTextField();
        t1.setBounds(550, 305, 250, 30);
        t1.setForeground(Color.RED);
        t1.addActionListener(this);
        f.add(t1);;

        a1 = new JLabel("MOBILE NUMBER:");
        a1.setBounds(350, 300, 170, 40);
        a1.setForeground(Color.WHITE);
        a1.setFont(new Font("Monospaced", Font.BOLD, 20));
        f.add(a1);
        

       /* t2 = new JTextField();
        t2.setBounds(550, 370, 250, 30);
        t2.setForeground(Color.red);
        t2.addActionListener(this);
        f.add(t2);

        a2 = new JLabel("STRUDENT ID:");
        a2.setBounds(370, 365, 150, 40);
        a2.setForeground(Color.WHITE);
        a2.setFont(new Font("Monospaced", Font.BOLD, 20));
        f.add(a2);*/

        t3 = new JTextField();
        t3.setBounds(550, 370, 250, 30);
        t3.setForeground(Color.red);
        t3.addActionListener(this);
        f.add(t3);

        a3 = new JLabel("AMOUNT:");
        a3.setBounds(430, 365, 150, 40);
        a3.setForeground(Color.WHITE);
        a3.setFont(new Font("Monospaced", Font.BOLD, 20));
        f.add(a3);

        b1 = new JButton("CONFROM");
        b1.setBounds(620, 450, 120, 30);
        b1.setFont(new Font("Monospaced", Font.BOLD, 20));
        b1.setForeground(Color.RED);
        f.add(b1);
        b1.addActionListener(this);
        
        
        b2 = new JButton("LOG OUT");
        b2.setBounds(1000,90,200,60);
        b2.setOpaque(true);
        b2.setContentAreaFilled(false);
        b2.setBorderPainted(false);
        b2.setForeground(Color.WHITE);
        b2.setFont(new Font("Monospaced", Font.BOLD, 20));
        f.add(b2);
        b2.addActionListener(this);
        
        
        
        b3 = new JButton("<-BACK");
        b3.setBounds(2,10,150,60);
        b3.setOpaque(true);
        b3.setContentAreaFilled(false);
        b3.setBorderPainted(false);
        b3.setForeground(Color.WHITE);
        b3.setFont(new Font("DialogInput", Font.BOLD, 16));
        f.add(b3);
        b3.addActionListener(this);
        
        
        
        
        
        
        
        
        
        
        
        f.add(panel);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationByPlatform(true);
        f.setSize(1370, 790);
        f.setVisible(true);
        f.setResizable(false);
        
        
        
        
        
    }
     public void actionPerformed(ActionEvent e) 
    {
        String number = t1.getText();
        String amount = t3.getText();
        
        if(e.getSource()==b2)
        {
           
            f.dispose();
            try {
                new Admin();
            } catch (IOException ex) {
                Logger.getLogger(Student_bill.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        }
         if(e.getSource()==b3)
        {
            f.dispose();
            new Home();
        }
         
        if(e.getSource()==b1)
        {
             if(number.length()==11)
            {
            Mobile_connectore s1 = new Mobile_connectore(number,amount);
            f.dispose();
            new Mobile_bangking();
            }
             else{
               JOptionPane.showMessageDialog(null, "Please Number only 11 Digit");
                
            }
        }
         
         
        
    }
    
}
