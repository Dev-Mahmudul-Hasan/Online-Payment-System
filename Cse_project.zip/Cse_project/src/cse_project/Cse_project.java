
package cse_project;

import java.io.IOException;


public class Cse_project {

   
    public static void main(String[] args) throws IOException 
    {
        new Progress();
       
    }
    
}
